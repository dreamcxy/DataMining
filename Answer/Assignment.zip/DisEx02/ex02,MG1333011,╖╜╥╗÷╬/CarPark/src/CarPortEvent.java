
public class CarPortEvent {
	final static int EVENT_CAR_IN = 0;
	final static int EVENT_CAR_OUT = 1;
	final static int EVENT_REMAIN_DEC = 2;
	final static int EVENT_REMAIN_INC = 3;
	
	int type;
	int data;
	public CarPortEvent(int type) {
		this.type = type;
	}
	
	public CarPortEvent(int type, int data)
	{
		this.type = type;
		this.data = data;
	}
}
