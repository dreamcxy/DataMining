import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.concurrent.LinkedBlockingQueue;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class CarPort extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	final static int CAR_PORT_OUT = 0;
	final static int CAR_PORT_IN = 1;
	
	int id;
	int remain;
	LinkedBlockingQueue<CarPortEvent> eventQueue;
	LinkedBlockingQueue<Integer> outRequests;
	MiddleWareLayer middleWare;
	
	Thread carThread = null;
	
	JLabel displayLabel;
	JButton carButton;
	
	public CarPort(int id, int n, int remain, int type)
	{
		this.id = id;
		this.remain = remain;
		this.middleWare = new MiddleWareLayer(id, n, this);
		this.eventQueue = new LinkedBlockingQueue<CarPortEvent>();
		
		JLabel title = new JLabel();
		if (type == CAR_PORT_IN)
			title.setText("��ڱ��:"+id);
		else
			title.setText("���ڱ��:"+id);
		
		displayLabel = new JLabel("ʣ�೵λ:"+remain);
		
		
		if (type == CAR_PORT_IN)
		{
			carButton = new JButton("����"); 
			carButton.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					eventQueue.add(new CarPortEvent(CarPortEvent.EVENT_CAR_IN));
				}
			});
		}
		else {
			outRequests = new LinkedBlockingQueue<Integer>();
			carButton = new JButton("����");
			carButton.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					eventQueue.add(new CarPortEvent(CarPortEvent.EVENT_CAR_OUT));
				}
			});
		}
		
		
		setLayout(null);
		setBorder(BorderFactory.createLineBorder(Color.BLACK));
		setSize(100,100);
		title.setBounds(10, 10, 80, 20);
		displayLabel.setBounds(10, 40, 80, 20);
		carButton.setBounds(10, 70, 80, 20);
		
		add(title);
		add(displayLabel);
		add(carButton);
	}
	
	void addMessage(String message)
	{
		CarPark.getInstance().addMessage(message);
	}
	
	void updateRemainDisplay()
	{
		displayLabel.setText("ʣ�೵λ:"+remain);
	}
	
	void processMessage(Message message)
	{
		if (message.type == Message.MESSAGE_CAR_IN)
			eventQueue.add(new CarPortEvent(CarPortEvent.EVENT_REMAIN_DEC,message.sender));
		else
		if (message.type == Message.MESSAGE_CAR_OUT)
			eventQueue.add(new CarPortEvent(CarPortEvent.EVENT_REMAIN_INC,message.sender));
	}
	
	void processEventCarIn()
	{
		if (carThread!=null)
		{
			addMessage("���г���"+id+"�ſڽ���,���Ժ���");
			return;
		}
		
		carThread = new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				
				Mutex mutex = middleWare.getMutex();
				OperationLatch latch = middleWare.getLatch();
				
				addMessage(""+id+"�ſ�:�����ȴ�ʻ�복��");
				
				mutex.enter();
				
				if (remain <=0 )
				{
					addMessage(""+id+"�ſ�:�����������޷�����");
					mutex.leave();
					carThread = null;
					return;
				}
				
				addMessage(""+id+"�ſ�:�����ɹ�ʻ�복��,����ϵͳ����");
				
				--remain;
				updateRemainDisplay();
				middleWare.boardcast(new Message(Message.MESSAGE_CAR_IN));
				latch.countDown();
				
				mutex.leave();
				
				addMessage(""+id+"�ſ�:ϵͳ���ݸ������");
				carThread = null;
				
			}
		});
		carThread.start();
		
	}
	
	synchronized void processEventCarOut()
	{
		outRequests.add(1);
		addMessage(""+id+"�ſ�:�����ɹ�ʻ��,�ȴ�����ϵͳ����");
		
		if (carThread!=null) return;
		
		carThread = new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				
				while (true)
				{
					try {
						outRequests.take();
						Mutex mutex = middleWare.getMutex();
						OperationLatch latch = middleWare.getLatch();
						
						mutex.enter();
						
						++remain;
						updateRemainDisplay();
						middleWare.boardcast(new Message(Message.MESSAGE_CAR_OUT));
						latch.countDown();
						
						mutex.leave();
						
						addMessage(""+id+"�ſ�:ϵͳ���ݸ������");
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		});
		carThread.start();
	}
	
	void processEventRemainDec(CarPortEvent e)
	{
		--remain;
		updateRemainDisplay();
		middleWare.send(e.data, new Message(Message.MESSAGE_ACK));
	}
	
	void processEventRemainInc(CarPortEvent e)
	{
		++remain;
		updateRemainDisplay();
		middleWare.send(e.data, new Message(Message.MESSAGE_ACK));
	}
	
	public void start()
	{
		middleWare.start();
		
		Thread aThread = new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				while (true)
				{
					try {
						CarPortEvent event = eventQueue.take();
						
						switch (event.type) {
						case CarPortEvent.EVENT_CAR_IN:
							processEventCarIn();
							break;
						case CarPortEvent.EVENT_CAR_OUT:
							processEventCarOut();
							break;
						case CarPortEvent.EVENT_REMAIN_DEC:
							processEventRemainDec(event);
							break;
						case CarPortEvent.EVENT_REMAIN_INC:
							processEventRemainInc(event);
							break;
						default:
							break;
						}
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		});
		
		aThread.start();
	}
}
