public class Message implements Comparable<Message> {
	final static int MESSAGE_REQUEST = 0;
	final static int MESSAGE_REPLY = 1;
	final static int MESSAGE_ACK = 2;
	final static int MESSAGE_CAR_IN = 3;
	final static int MESSAGE_CAR_OUT = 4;
	int type;
	int timestamp;
	int sender;

	public Message(int type) {
		// TODO Auto-generated constructor stub
		this.type = type;
	}

	public Message(int type, int timestamp, int sender) {
		this.type = type;
		this.timestamp = timestamp;
		this.sender = sender;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(int timestamp) {
		this.timestamp = timestamp;
	}

	public int getSender() {
		return sender;
	}

	public void setSender(int sender) {
		this.sender = sender;
	}

	@Override
	public int compareTo(Message o) {
		// TODO Auto-generated method stub

		int res = this.timestamp - o.timestamp;
		if (res == 0)
			res = this.sender - o.sender;
		return res;
	}
}
