import java.util.concurrent.LinkedBlockingQueue;


public class OperationLatch {
	LinkedBlockingQueue<Message> messageQueue;
	MiddleWareLayer middleWare;
	
	public OperationLatch(MiddleWareLayer middleWare) {
		messageQueue = new LinkedBlockingQueue<Message>();
		this.middleWare = middleWare;
	}
	
	
	public void processMessage(Message message)
	{
		messageQueue.add(message);
	}
	
	public void countDown()
	{
		int n = middleWare.getTotalMachineNumber();
		int ack = 0;
		boolean[] acked = new boolean[n];
		
		while (ack<n-1)
		{
			try {
				Message message = messageQueue.take();
				if (acked[message.sender] == false)
				{
					acked[message.sender] = true;
					ack++;
				}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		messageQueue.clear();
	}
	
}
