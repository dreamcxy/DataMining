import java.util.Random;
import java.util.concurrent.LinkedBlockingQueue;

public class MiddleWareLayer {
	Integer localTime; // �����߼�ʱ��
	int id; // �������
	int totalMachineNumber; // ϵͳ�л�������

	LinkedBlockingQueue<Message> messageQueue;
	Mutex mutex;
	OperationLatch latch;
	CarPort port;

	public MiddleWareLayer(int id, int n, CarPort port) {
		// TODO Auto-generated constructor stub
		localTime = 0;
		this.id = id;
		this.port = port;
		totalMachineNumber = n;
		messageQueue = new LinkedBlockingQueue<Message>();
		this.mutex = new Mutex(this);
		this.latch = new OperationLatch(this);
		NetWorkLayer.access(id, messageQueue);
	}

	public void send(int targetId, Message message) {
		message.setSender(id);
		synchronized (localTime) {
			++localTime;
			message.setTimestamp(localTime);
		}
		NetWorkLayer.transfer(targetId, message);
	}

	public void boardcast(Message message) {
		message.setSender(id);
		synchronized (localTime) {
			++localTime;
			message.setTimestamp(localTime);
		}

		for (int i = 0; i < totalMachineNumber; ++i)
			if (i != id)
				NetWorkLayer.transfer(i, message);
	}
	
	public void preSetMessageTime(Message message)
	{
		synchronized (localTime) {
			++localTime;
			message.setTimestamp(localTime);
		}		
	}
	
	public void boardcastWithOutSetTime(Message message)
	{	
		message.setSender(id);
		for (int i=0; i < totalMachineNumber; ++i)
			if (i!=id)
				NetWorkLayer.transfer(i, message);
	}

	public void start() {
		Thread aThread = new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				Random r = new Random();
				while (true) {
					try {
						Message message = messageQueue.take();
						if (message.timestamp >= localTime)
							Thread.sleep(r.nextInt(800));
						processMessage(message);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		});
		aThread.start();
	}

	public void processMessage(Message message) {
		synchronized (localTime) {
			if (message.timestamp > localTime) 
				localTime = message.timestamp;
			localTime = localTime + 1;
		}

		//System.out.println(id + "receive :" +message.type + " sender:" + message.sender);
		
		if (message.type == Message.MESSAGE_REQUEST
				|| message.type == Message.MESSAGE_REPLY) {
			mutex.processMessage(message);
		} else if (message.type == Message.MESSAGE_ACK) {
			latch.processMessage(message);
		}
		if (message.type == Message.MESSAGE_CAR_IN
				|| message.type == Message.MESSAGE_CAR_OUT) {
			port.processMessage(message);
		}
	}

	public int getLocalTime() {
		return localTime;
	}

	public void setLocalTime(int localTime) {
		this.localTime = localTime;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getTotalMachineNumber() {
		return totalMachineNumber;
	}

	public void setTotalMachineNumber(int totalMachineNumber) {
		this.totalMachineNumber = totalMachineNumber;
	}

	public LinkedBlockingQueue<Message> getMessageQueue() {
		return messageQueue;
	}

	public void setMessageQueue(LinkedBlockingQueue<Message> messageQueue) {
		this.messageQueue = messageQueue;
	}

	public Mutex getMutex() {
		return mutex;
	}

	public void setMutex(Mutex mutex) {
		this.mutex = mutex;
	}

	public OperationLatch getLatch() {
		return latch;
	}

	public void setLatch(OperationLatch latch) {
		this.latch = latch;
	}

	public CarPort getPort() {
		return port;
	}

	public void setPort(CarPort port) {
		this.port = port;
	}

	public void setLocalTime(Integer localTime) {
		this.localTime = localTime;
	}
}
