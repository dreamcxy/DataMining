import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class CarPark extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static CarPark instance = null;
	
	static CarPark getInstance()
	{
		if (instance == null)
			instance = new CarPark();
		return instance;
	}
	
	JTextField remainField;
	JTextField entranceField;
	JTextField exitField;
	JTextArea messageArea;
	JButton showButton;
	JScrollPane scrollPane;
	
	private CarPark()
	{
		setLayout(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(800, 600);
		
		JLabel label1 = new JLabel("�ܳ�λ��");
		JLabel label2 = new JLabel("�����");
		JLabel label3 = new JLabel("������");
		
		remainField = new JTextField("10");
		entranceField = new JTextField("3");
		exitField = new JTextField("3");
		
		showButton = new JButton("��ʼչʾ");
		
		label1.setBounds(20, 20, 60, 20);
		remainField.setBounds(80, 20, 40, 20);
		label2.setBounds(200,20,60,20);
		entranceField.setBounds(260,20,40,20);
		label3.setBounds(400,20,60,20);
		exitField.setBounds(460, 20, 40, 20);
		
		showButton.setBounds(600,20,100,20);
		
		add(label1);
		add(remainField);
		add(label2);
		add(entranceField);
		add(label3);
		add(exitField);
		add(showButton);
		
		showButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				beginShow();
			}
		});
		
		messageArea = new JTextArea();
		scrollPane = new JScrollPane(messageArea);
		scrollPane.setBounds(30, 430, 720, 125);
		add(scrollPane);
	}
	
	public void addMessage(String message)
	{
		messageArea.setText(messageArea.getText() + message + "\n");
		JScrollBar scrollBar = scrollPane.getVerticalScrollBar();
		if (scrollBar!=null)
			scrollBar.setValue(scrollBar.getMaximum());
	}
	
	public void beginShow()
	{
		int n,remain,entrance,exit;
		
		remain = Integer.parseInt(remainField.getText());
		entrance = Integer.parseInt(entranceField.getText());
		exit = Integer.parseInt(exitField.getText());
		n = entrance + exit;
		
		CarPort[] ports = new CarPort[n];
		
		for (int i=0;i<n;++i)
		{
			ports[i] = new CarPort(i, n, remain, i<entrance?CarPort.CAR_PORT_IN:CarPort.CAR_PORT_OUT);
			ports[i].setLocation(10 + i%7 * 110, 100+i/7 * 110);
			this.add(ports[i]);
		}
		this.repaint();
		
		showButton.setEnabled(false);
		
		for (int i=0;i<n;++i)
			ports[i].start();
	}
	
	public static void main(String[] args)
	{
		CarPark carPark = CarPark.getInstance();
		carPark.setVisible(true);
	}
}
