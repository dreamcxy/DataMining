import java.util.ArrayList;
import java.util.concurrent.LinkedBlockingQueue;

class Mutex {
	final static int STATE_OUT_OF_CRITICAL_AREA = 0;
	final static int STATE_IN_CRITICAL_AREA = 1;
	final static int STATE_WANT_IN_CRITICAL_AREA = 2;

	int state;
	Message request;
	MiddleWareLayer middleWare;
	LinkedBlockingQueue<Message> messageQueue;
	ArrayList<Message> savedQueue;

	Mutex(MiddleWareLayer middleWare) {
		this.middleWare = middleWare;
		this.messageQueue = new LinkedBlockingQueue<Message>();
		this.savedQueue = new ArrayList<Message>();
		this.state = STATE_OUT_OF_CRITICAL_AREA;
	}

	public void processMessage(Message message) {
		if (state == STATE_OUT_OF_CRITICAL_AREA) {
			if (message.type == Message.MESSAGE_REQUEST) {
				Message reply = new Message(Message.MESSAGE_REPLY);
				middleWare.send(message.sender, reply);
			}
		} else if (state == STATE_IN_CRITICAL_AREA) {
			if (message.type == Message.MESSAGE_REQUEST)
				savedQueue.add(message);
		} else if (state == STATE_WANT_IN_CRITICAL_AREA) {
			if (message.type == Message.MESSAGE_REPLY)
				messageQueue.add(message);
			else if (message.type == Message.MESSAGE_REQUEST) {
				if (message.compareTo(request) < 0) {
					Message reply = new Message(Message.MESSAGE_REPLY);
					middleWare.send(message.sender, reply);
				} else {
					savedQueue.add(message);
				}
			}
		}
	}

	public void enter() {
		int n;
		boolean[] replyed;
		int reply;

		messageQueue.clear();
		savedQueue.clear();

		request = new Message(Message.MESSAGE_REQUEST);
		middleWare.preSetMessageTime(request);
		state = STATE_WANT_IN_CRITICAL_AREA;
		middleWare.boardcastWithOutSetTime(request);

		n = middleWare.getTotalMachineNumber();
		replyed = new boolean[n];
		reply = 0;

		while (reply < n - 1) {
			try {
				Message message = messageQueue.take();
				if (replyed[message.sender] == false) {
					replyed[message.sender] = true;
					++reply;
				}

			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		state = STATE_IN_CRITICAL_AREA;
	}

	public void leave() {
		state = STATE_OUT_OF_CRITICAL_AREA;
		for (int i = 0; i < savedQueue.size(); ++i) {
			Message message = savedQueue.get(i);
			Message reply = new Message(Message.MESSAGE_REPLY);
			middleWare.send(message.sender, reply);
		}
	}
};
