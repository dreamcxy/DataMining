import java.util.HashMap;
import java.util.concurrent.LinkedBlockingQueue;


public class NetWorkLayer {
	static HashMap<Integer, LinkedBlockingQueue<Message>> network = new HashMap<Integer, LinkedBlockingQueue<Message>>();
	public static void access(int machineId, LinkedBlockingQueue<Message> wire)
	{
		network.put(machineId, wire);
	}
	
	public static void transfer(int targetId, Message message)
	{
		LinkedBlockingQueue<Message> targetWire = network.get(targetId);
		targetWire.add(message);
	}
}
