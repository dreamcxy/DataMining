package ClientInterfaceImplement;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Date;
import ClientInterface.TimeClientInterface;
/**
 * 
 * @author bingjiang
 *
 */
public class TimeInterfaceImp extends UnicastRemoteObject implements TimeClientInterface{
	public static final long serialVersionUID = 10L;
	
	public TimeInterfaceImp() throws RemoteException {
		
	}
	
	public void display(Date time) throws RemoteException {
		System.out.println("***Digit Clock Client, the current time is: ");
		System.out.println("***" + time);
	}

}
