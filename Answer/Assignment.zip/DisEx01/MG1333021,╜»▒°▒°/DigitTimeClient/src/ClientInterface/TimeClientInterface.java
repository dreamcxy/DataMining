package ClientInterface;
import java.rmi.Remote;

import java.rmi.RemoteException;
import java.util.Date;
/**
 * 
 * @author bingjiang
 *
 */
public interface TimeClientInterface extends Remote{
	public void display(Date time) throws RemoteException;

}
