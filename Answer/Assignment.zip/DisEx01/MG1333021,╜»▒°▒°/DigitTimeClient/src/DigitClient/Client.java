package DigitClient;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

import ServerInterface.TimeServerInterface;
import ClientInterface.TimeClientInterface;
import ClientInterfaceImplement.TimeInterfaceImp;
/**
 * 
 * @author bingjiang
 *
 */
public class Client {
	private static final String URL = "//127.0.0.1";
	private static final int PORT = 8888;
	
	public static void main(String[] args) {
		System.out.println("***Digit Clock Starting*** ");
		System.out.println("**Register Starting***");		
		try {
			TimeServerInterface ts = (TimeServerInterface)Naming.lookup(URL + ":" + PORT + "/TimeServerInterface");				
			System.out.println("***The Current Time From TimeServer Is: ");
			System.out.println("***" + ts.getTime());
			System.out.println("***Register Over***");		
			TimeClientInterface tc = new TimeInterfaceImp();
			ts.regist(tc,2000);		
		} catch (RemoteException e) {
			e.printStackTrace();
		
		} catch (MalformedURLException e) {
			e.printStackTrace();
		
		} catch (NotBoundException e) {
			e.printStackTrace();
		}		
		System.out.println("***Digit Clock Working***");
	}


}
