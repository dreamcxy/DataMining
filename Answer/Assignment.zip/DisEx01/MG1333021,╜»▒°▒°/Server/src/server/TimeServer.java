package server;

import java.rmi.RemoteException;
import java.net.MalformedURLException;
import java.rmi.registry.LocateRegistry;
import java.rmi.Naming;
import ServerInterface.TimeServerInterface;
import ServerInterfaceImplement.ServerInterfaceImp;

/**
 * 
 * @author bingjiang
 *
 */
public class TimeServer {
	private static final String URL = "//127.0.0.1";
	private static final int PORT = 8888;
	
	public static void main(String[] args) {		
		System.out.println("***Server Starting***");		
		try {
			LocateRegistry.createRegistry(PORT);										
			TimeServerInterface ts = new ServerInterfaceImp();						
			Naming.rebind(URL + ":" + PORT + "/TimeServerInterface", ts);	
		
		} catch (RemoteException e) {
			e.printStackTrace();
		
			System.out.println("***Not Founding Server***");
			System.exit(1);
		
		} catch (MalformedURLException e) {
			e.printStackTrace();
			
			System.out.println("***Not Founding Server***");
			System.exit(1);

	
		} finally {
		}	
		System.out.println("***Server Listening At: ***" + URL + ":" + PORT);
	}


}
