package ServerInterfaceImplement;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.TreeMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Date;

import ServerInterface.TimeServerInterface;
import ClientInterface.TimeClientInterface;
/**
 * 
 * @author bingjiang
 *
 */
public class ServerInterfaceImp extends UnicastRemoteObject implements TimeServerInterface{
	public static final long serialVersionUID = 11L;
	
	private TreeMap<TimeClientInterface, Timer> clients;
	
	public ServerInterfaceImp() throws RemoteException {	
		clients = new TreeMap<TimeClientInterface, Timer>();
	}	
	
	private void addClient(TimeClientInterface timeClient, Timer timer) {
		clients.put(timeClient, timer);
	}
	
	public void regist(final TimeClientInterface timeClient) throws RemoteException {
		regist(timeClient, 1000);	
	}
	
	public void regist(final TimeClientInterface timeClient, int seconds) throws RemoteException {
		Timer timer = new Timer();
		TimerTask callback = new TimerTask() {
			public void run() {			
				try {
					timeClient.display(new Date());
				} catch (RemoteException e) {
					e.printStackTrace();
				}
			}
		};
		addClient(timeClient, timer);
		timer.schedule(callback, 0, seconds);
	}

	public Date getTime() throws RemoteException {
		return new Date();
	}




}
