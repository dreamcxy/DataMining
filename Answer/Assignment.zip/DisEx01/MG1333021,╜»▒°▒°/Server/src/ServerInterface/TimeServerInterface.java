package ServerInterface;
import java.rmi.Remote;

import java.rmi.RemoteException;
import java.util.Date;
import ClientInterface.TimeClientInterface;
/**
 * 
 * @author bingjiang
 *
 */
public interface TimeServerInterface extends Remote{
	public void regist(TimeClientInterface timeClient) throws RemoteException;
	
	public void regist(TimeClientInterface timeClient,int seconds) throws RemoteException;
	
	public Date getTime() throws RemoteException;

}
