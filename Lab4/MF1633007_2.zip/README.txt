def loadDateSet(file_name): 导入数据
def log(fileName, lamda, num): 利用log-likelihood
def ridge(fileName, lamda, num):	利用ridge-regression
def test(fileName, w): 	计算准确率

可直接运行，更改文件名即可
画图利用excel，对result.xlsx中的数据进行绘图即可