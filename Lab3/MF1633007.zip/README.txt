spectral.py 和 kmedoid.py 为运行代码
spectral.py 可以直接运行。
kMedoid.py 为了得到结果需要更改文件名